import pandas as pd
import matplotlib.pyplot as plt
import xlrd
df=pd.read_excel('bookstall.xlsx)
print(df)

x= df['type_of_book']
y= df['sales']
plt.bar(x, y, label=' Bookstall', color='red')
plt.xlabel('id')
plt.ylabel('salary')
plt.title('Department book')
plt.legend()
plt.show()
#===============================================================
import matplotlib.pyplot as plt
x=[101,109,103,105,107,110]
y=[10010,11109,20003,25007,31010]
x1=[105,108,102,106,111]
y1=[20110,31109,35003,29007,39010]
plt.bar(x, y, label=' Production', color='blue')
plt.bar(x1, y1, label=' QA depa.', color='red')
plt.xlabel('Employee_id')
plt.ylabel('salary')
plt.title('TATA Company')
plt.legend()
plt.show()

#===============================================================
import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv('file.csv')
x= df['id']
y= df['salary']
plt.bar(x, y, label=' production Department', color='red')
plt.xlabel('id')
plt.ylabel('salary')
plt.title('Department data')
plt.legend()
plt.show()

#===============================================================
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import xlrd
df=pd.read_excel('stationary.xlsx)
print(df)

year=[2021,2022,2023]
x=df['pencil']
x1=df['pen']

xaxis=np.arange(len(year))
plt.bar(xaxis-0.2, x,0.4, label=' pencil')
plt.bar(xaxis-0.2, x1,0.4, label=' pen')
plt.xticks(xaxis,year)
plt.xlabel('product')
plt.ylabel('sales')
plt.title('Student_store')
plt.legend()
plt.show()
