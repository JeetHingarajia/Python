# 1. Create a file with file name sample.txt, accept some data from the user and store it in the file.

# f = open('sample.txt', 'w')
# data = input("Enter some data you want to write into the file : ")
# f.write(data)
# print("Data has been stored in sample.txt.")
# f.close()


#==============================================================================

# 2. Display the data stored in the sample.txt file (created in question 1).

# f = open('sample.txt', 'r')
# data = f.read()
# print(data)
# f.close()

#==============================================================================

# 3. Accept some data from the user and append it into the file sample.txt (created in question 1),
# also the data in the file.

# f = open('sample.txt', 'a')
# new_data = input("Enter new data to append to sample.txt: ")
# f.write(new_data)
# print("All data stored in sample.txt after appending:")
# f.close()

#==============================================================================

# 4. Accept the file name from the user, check the availability of the file: i). If the file exists display
# the data on the screen, ii). If the file is not available, display the appropriate message.

# import os

# fname = input('Enter the name of file to open : ')
# if os.path.isfile(fname):
#     f = open(fname , 'r')
#     data = f.read()
#     print(data)
# else : 
#     print('The file does not exist')

#==============================================================================

# 5. Accept the file name from the user, check the availability of the file:
# a. If the file exists, display: i). No. of characters, ii). No. of words and iii). No. of lines
# b. If the file does exist, than display the appropriate message.

# import os 
# fname = input('Enter the name of file to open : ')
# if os.path.isfile(fname) :
#     f = open(fname , 'r')
#     # data = f.read()
#     # print(data)
# else : 
#     print('The file does not exist')
# cl=cw=cc=0
# for line in f : 
#     words = line.split()
#     cl = cl + 1 
#     cw= cw + len(words)
#     cc = cc + len(line) 
# print('Number of line in a file is : ' ,cl)
# print('Number of words in a file is : ' ,cw)
# print('Number of characters in a file is : ' ,cc)
# f.close()

#==============================================================================

# 6. Create and open the binary file with ‘with’ option. Store names of all the subjects you study in
# semester 2. Ask user to enter the subject number they wanted to see and display that subject name.

# with open('subject.bin' , 'wb') as f:
#     n = int(input('how many subject you want to insert ? :'))
#     for i in range (n) : 
#         subject = input('Enter the name of a subject : \t')
#         n = len(subject)
#         subject = subject.encode() + b', '
#         f.write(subject)
#     print('--------------------------------')
# with open('subject.bin','rb') as f:
#     sub = f.read()
#     print('------------------ subject is ----------------')
#     print(sub.decode( ))

#==============================================================================
    
# # 7. Create a file named ‘img1’, store an image into it. Open another file named ‘img2’, copy the
# # same image as in the file ’img1’. Also store both files into the zip file named ‘imp_img’.
    
# from zipfile import *
# import shutil

# shutil.copy('image.jpg', 'img1.jpg')

# shutil.copy('img1.jpg', 'img2.jpg')

# f= ZipFile('imp_img' , 'w' , ZIP_DEFLATED)

# f.write('img1.jpg')
# f.write('img2.jpg')
# f.close()

# #==============================================================================

# # 8. Create a file with ‘with’ option, name it as ‘marks.dat’.
# # i). Accept subject name and marks from the user, store the data in the file.
# # ii). Give three options to the user: a). To view whole file, b). Accept and edit the marks of a
# # subject user want to change. iii). Exit


# import mmap, sys
# with open ('marks.dat' , 'wb') as f : 
#     n = int(input('How many record to enter ? : '))
#     for i in range(n):
#         subject = input('Enter Subject name : ')
#         marks  = input("Enter subject marks : ")
#         subject = subject.encode()+ b' : '
#         marks = marks.encode()+ b', '
#         f.write(subject + marks)
# while True:
#     print('1. View all the data of the file')
#     print('2. Accept and edit the marks of a subject user wants to change')
#     print('3. Exit')

#     ch = int(input('Enter your choice: '))

#     if ch == 3:
#         sys.exit()

#     with open('marks.dat', 'r+b') as f:
#         mm = mmap.mmap(f.fileno(), 0)
#         if ch == 1:
#             print('------------------------------------')
#             print(mm.read().decode())
#             print('------------------------------------')
#         if ch == 2:
#             subject = input('Enter the name of the subject to modify subject marks: ')
#             n = mm.find(subject.encode())
#             if n != -1:
#                 n1 = n + len(subject)
#                 new_marks = input("Enter the updated subject marks: ")
#                 mm[n1:n1 + 4] = new_marks.encode()+ b' : '
#             else:
#                 print("Subject not found.")
# # =============================================================================
                
# 9. Create a regular expression that:
# a). Identifies and display the string  characters starting with ‘s’ and having 4 characters.
# b). Splits the string where some special characters are found.
# c). Display the word starting with number.
# d). Display the word having 3 or 4 or 5 characters.
# e). Display only the dates from the string.
# f). Create a string with name of the person and his Aadhar number, display only Aadhar
# number.
# g). Display all the words that starts with ‘at’ or ‘ap’.
# h). Check if the string starts with ‘at’ than display appropriate message and otherwise

# import re

# str1 = "The sun is shining."
# # 1)
# result_a = re.findall(r's[\w]{2}', str1)
# print(result_a)  

# # 2)
# str2 = "Hello! How are you?"

# result_b = re.split(r'[^\w]+', str2)
# print(result_b) 

# # 3)
# str3 = "The 7th wonder of the world."
# result_c = re.findall(r'\b\d\w*\b', str3)
# print(result_c)  

# #4)

# str4 = "The sky is blue."

# result_d = re.findall(r'\b\w{3,5}\b', str4)
# print(result_d)  

# #5)

# str5 = "Today is 18-04-2024, and tomorrow is 19-04-2024."

# result_e = re.findall(r'\b\d{2}-\d{2}-\d{4}\b', str5)
# print(result_e)  

# #6)

# str6 = "Name: rahul kanjariya, Aadhar: 4161 4587 1303"

# result_f = re.findall(r'\b\d{4} \d{4} \d{4}\b', str6)
# print(result_f) 

# #7)

# str7 = "The cat sat on the mat. An apple fell from the apple tree."

# result_g = re.findall( r'a[tp][\w]*', str7)
# print(result_g)  

# # 8)


# str8 = "atmiya university"
# if re.match(r'^at', str8):
#     print("String starts with 'at'")
# else:
#     print("String does not start with 'at'")

# # =============================================================================

# 10. Do as directed:
# a). Name the package used to deal with data frame.
# b). Name the package used to deal with data .xlsx file.
# c). Name the function used to read the .csv file.
# d). Name the function used to read the .xlsx file.
# e). Name the function used to read the tuple

# a) The package used to deal with data frames in Python is called pandas.

# b) The package used to deal with Excel files, including .xlsx files, in Python is called openpyxl.

# c) The function used to read a .csv file in Python is pandas.read_csv().

# d) The function used to read a .xlsx file in Python is pandas.read_excel().

# e) There isn't a specific function to read a tuple in Python because tuples are a basic data type and can be easily created without the need for a specific function.

# # =============================================================================

# 11. Create a dictionary which stores (at least 10 records)empid, name, city, salary and perform
# following operations:
# a). Display first three records
# b). Display last five records
# c). Display only Name and City
# d). Display employee who belongs to Mumbai
# e). Display employee name who belongs to Mumbai
# f). Display employee whose salary is more than 25000


# Create a dictionary with employee records
# employee_records = [
#     {"empid": 1, "name": "John", "city": "Mumbai", "salary": 30000},
#     {"empid": 2, "name": "Alice", "city": "Delhi", "salary": 28000},
#     {"empid": 3, "name": "Bob", "city": "Bangalore", "salary": 35000},
#     {"empid": 4, "name": "Emma", "city": "Mumbai", "salary": 27000},
#     {"empid": 5, "name": "Jack", "city": "Chennai", "salary": 26000},
#     {"empid": 6, "name": "Sophia", "city": "Mumbai", "salary": 32000},
#     {"empid": 7, "name": "Liam", "city": "Bangalore", "salary": 30000},
#     {"empid": 8, "name": "Olivia", "city": "Delhi", "salary": 24000},
#     {"empid": 9, "name": "Noah", "city": "Mumbai", "salary": 28000},
#     {"empid": 10, "name": "Ava", "city": "Chennai", "salary": 27000}
# ]

# # a) Display first three records
# print("First three records:")
# print(employee_records[:3])

# # b) Display last five records
# print("\nLast five records:")
# print(employee_records[-5:])

# # c) Display only Name and City
# print("\nName and City:")
# print([{"name": employee_records["name"], "city": record["city"]} for record in employee_records])

# # d) Display employee who belongs to Mumbai
# print("\nEmployees from Mumbai:")
# print([record for record in employee_records if record["city"] == "Mumbai"])

# # e) Display employee name who belongs to Mumbai
# print("\nEmployee names from Mumbai:")
# print([record["name"] for record in employee_records if record["city"] == "Mumbai"])

# # f) Display employee whose salary is more than 25000
# print("\nEmployees with salary more than 25000:")
# print([record for record in employee_records if record["salary"] > 25000])

# # =============================================================================

# 12. Create an xlsx file store marks of five subjects, plot the data on the bar graph.

import pandas as pd
import matplotlib.pyplot as plt
import xlrd

df = pd.read_excel('file.xlsx')


x= df['subject_name']
y= df['Subject_marks']

# creating the line graph using bar()
plt.bar(x, y, label='Student Marks', color='red')

# setting labels for x-axis and y-axis 
plt.xlabel('subject_name')
plt.ylabel('subject_mark')

# setting title and labels
plt.title('Sutdent data')

# showing the legend 
plt.legend()

# display the graph
plt.show()




