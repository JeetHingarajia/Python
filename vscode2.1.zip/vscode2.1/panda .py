import pandas as pd
import xlrd
df=pd.read-excel('stud.xlsx')
print(df)

print(df.shape)
print(df.head)
print(df.tail)

print(df.[2:4])
print(df['name','city'])
print(df['marks'].max())

print(df[df.marks>50])
print(df[df.city='Rajkot'])

#clean data
import pandas as pd
import xlrd
df=pd.read-excel('stud.xlsx')
print(df)

df1=df.fillna('Name':'Name_missing',
               'Mark':'Mark_missing',
               'City':'City_missing')
print(df1)



